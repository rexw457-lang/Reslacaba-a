import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";
import cors from "cors";
import swaggerUi from "swagger-ui-express";
import swaggerJsdoc from "swagger-jsdoc";

import restaurantRoutes from "./src/routes/restaurant.routes.js";
import menuItemRoutes from "./src/routes/menuItem.routes.js";
import orderRoutes from "./src/routes/order.routes.js";
import authRoutes from "./src/routes/auth.routes.js";
import userRoutes from "./src/routes/user.routes.js";
import roleRoutes from "./src/routes/role.routes.js";
import tableRoutes from "./src/routes/table.routes.js";
import reservationRoutes from "./src/routes/reservation.routes.js";

// Importar modelos
import Restaurant from "./src/models/Restaurant.js";
import MenuItem from "./src/models/MenuItem.js";
import Order from "./src/models/Order.js";
import Table from "./src/models/Table.js";
import Reservation from "./src/models/Reservation.js";
import Review from "./src/models/Review.js";
import User from "./src/models/User.js";
import Role from "./src/models/Role.js";


dotenv.config();

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(express.json({ limit: "100kb" }));

const allowedOrigins = (process.env.CORS_ORIGINS || "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5174,http://127.0.0.1:5174")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);

app.use(cors({
    origin(origin, callback) {
        if (!origin || allowedOrigins.includes(origin)) {
            return callback(null, true);
        }

        return callback(new Error("Origen no permitido por CORS"));
    },
    credentials: true
}));

const mongoUri = process.env.MONGO_URI;
if (!mongoUri) {
    console.error("Error: MONGO_URI no está definido. Crea un archivo .env con la variable MONGO_URI de tu conexión MongoDB.");
    process.exit(1);
}

mongoose.connect(mongoUri)
    .then(async () => {
        console.log("MongoDB conectado");
        await seedInternalProfiles();
        await migrateBebidasFriasCategories();
        await seedBaseMenuItems();
        await seedDefaultRestaurantAndTables();
    })
    .catch(err => console.error(err));

// Separa la categoría única "Bebidas frias" en tres categorías:
//   - "Bebidas - Sodas"
//   - "Bebidas Naturales"
//   - "Bebidas - Licuados"
//
// IMPORTANTE: en Orders.jsx, `isDrinkItem` decide si un platillo va a la
// impresora/vista de "bebidas" solo si su categoría contiene la palabra
// "bebidas" (category.includes('bebidas')). Por eso las categorías nuevas
// incluyen esa palabra — si les cambias el nombre, esos productos dejarían
// de imprimirse en la impresora de bebidas y se irían por error a cocina.
//
// A diferencia de seedBaseMenuItems (que busca por name+category y por eso
// crearía duplicados si solo le cambiáramos la categoría ahí), esta función
// busca SOLO por nombre y actualiza la categoría del producto que ya existe,
// sin tocar nombre, precio ni descripción. Correr esto varias veces es
// seguro: una vez migrado un producto, ya no vuelve a moverse.
const BEBIDAS_FRIAS_CATEGORY_MAP = {
    // --- Sodas --- (cubre "Coca" del seed automático y "Cocacola" por si
    // quedó de una corrección de precios anterior con ese nombre)
    "Coca": "Bebidas - Sodas",
    "Cocacola": "Bebidas - Sodas",
    "Sprite": "Bebidas - Sodas",
    "Orange": "Bebidas - Sodas",
    "Salvavidas (Soda)": "Bebidas - Sodas",
    "Mineral (Soda)": "Bebidas - Sodas",
    "Fanta": "Bebidas - Sodas",
    "Tiki": "Bebidas - Sodas",

    // --- Bebidas naturales ---
    "Limonada": "Bebidas Naturales",
    "Naranjada": "Bebidas Naturales",
    "LimoSoda": "Bebidas Naturales",
    "Naranjada Con Soda": "Bebidas Naturales",
    "Jamaica": "Bebidas Naturales",
    "Cimarrona": "Bebidas Naturales",

    // --- Licuados ---
    "Licuado de Fresa": "Bebidas - Licuados",
    "Licuado de Banano": "Bebidas - Licuados",
    "Licuado mixto": "Bebidas - Licuados",
    "Shakalaka": "Bebidas - Licuados",
};

// "Licuado de frutas" ya no existe como tal: se renombra a "Licuado mixto".
// Este renombre corre ANTES del mapa de categorías de arriba, para que
// "Licuado mixto" ya exista con ese nombre cuando el mapa busque por él.
const BEBIDAS_FRIAS_RENAMES = {
    "Licuado de frutas": "Licuado mixto",
};

// Nota: "Típico", "Tamarindo" y "Licuado mixto" ya no se crean aquí — están
// agregados directamente en la lista de `seedBaseMenuItems` (más abajo), que
// corre justo después de esta migración y los da de alta solos si faltan.
// Si "Tiki" ya es tu "Típico" en la vida real, borra la línea de "Típico" en
// esa lista para no terminar con dos productos casi iguales.

const migrateBebidasFriasCategories = async () => {
    try {
        let renamed = 0;
        for (const [oldName, newName] of Object.entries(BEBIDAS_FRIAS_RENAMES)) {
            const item = await MenuItem.findOne({ name: oldName, isDeleted: { $ne: true } });
            if (!item) continue;

            const collision = await MenuItem.findOne({ name: newName, isDeleted: { $ne: true } });
            if (collision) {
                // Ya existe un producto con el nombre nuevo (por ejemplo, si lo
                // creaste a mano antes de este deploy): no renombramos, para no
                // terminar con dos productos con el mismo nombre.
                console.log(`[Migración bebidas] Ya existe "${newName}"; no se renombró "${oldName}".`);
                continue;
            }

            item.name = newName;
            await item.save();
            renamed += 1;
            console.log(`[Migración bebidas] Renombrado: "${oldName}" -> "${newName}"`);
        }

        let updated = 0;
        for (const [name, category] of Object.entries(BEBIDAS_FRIAS_CATEGORY_MAP)) {
            const item = await MenuItem.findOne({ name, isDeleted: { $ne: true } });
            if (!item || item.category === category) continue;
            await MenuItem.updateOne({ _id: item._id }, { $set: { category } });
            updated += 1;
            console.log(`[Migración bebidas] ${name}: "${item.category}" -> "${category}"`);
        }

        if (renamed > 0 || updated > 0) {
            console.log(`[Migración bebidas] ${renamed} renombrado(s), ${updated} recategorizado(s).`);
        }
    } catch (error) {
        console.error("[Migración bebidas] Error:", error.message);
    }
};

const seedDefaultRestaurantAndTables = async () => {
    try {
        const defaultRestaurantName = process.env.SEED_RESTAURANT_NAME || "Los Rubios Rojos";
        let restaurant = await Restaurant.findOne({ name: defaultRestaurantName, isDeleted: { $ne: true } });
        if (!restaurant) {
            restaurant = await Restaurant.create({
                name: defaultRestaurantName,
                address: process.env.SEED_RESTAURANT_ADDRESS || "Centro gastronómico",
            });
        }

        const defaultTables = [
            { number: 1, name: "Mesa 1", capacity: 4 },
            { number: 2, name: "Mesa 2", capacity: 4 },
            { number: 3, name: "Mesa 3", capacity: 4 },
            { number: 4, name: "Mesa 4", capacity: 4 },
            { number: 5, name: "Mesa café", capacity: 4 },
            { number: 6, name: "Mesa butacas y sillas", capacity: 4 },
            { number: 7, name: "Mesa espejos", capacity: 4 },
            { number: 8, name: "Mesa congelador", capacity: 4 },
            { number: 9, name: "Mesa grande", capacity: 6 },
        ];

        for (const tableData of defaultTables) {
            const exists = await Table.findOne({ restaurant: restaurant._id, number: tableData.number, isDeleted: { $ne: true } });
            if (!exists) {
                await Table.create({
                    ...tableData,
                    restaurant: restaurant._id,
                    status: "disponible",
                });
                continue;
            }

            const updates = {};
            if (exists.name !== tableData.name) updates.name = tableData.name;
            if (exists.capacity !== tableData.capacity) updates.capacity = tableData.capacity;
            if (Object.keys(updates).length > 0) {
                await Table.updateOne({ _id: exists._id }, { $set: updates });
            }
        }

        console.log("[Seed] Mesas base verificadas.");
    } catch (error) {
        console.error("[Seed] Error al crear mesas base:", error.message);
    }
};

const seedBaseMenuItems = async () => {
    try {
        const baseItems = [
            { name: "Papas Supreme", category: "Entradas", description: "Papas con toppings." , price: 25, available: true },
            { name: "Nachos Supreme", category: "Entradas", description: "Nachos con queso y toppings.", price: 25, available: true },
            { name: "Papas fritas", category: "Entradas", description: "Papas fritas tradicionales.", price: 10, available: true },
            { name: "Papas con queso", category: "Entradas", description: "Papas con queso suave.", price: 15, available: true },
            { name: "Porción ajillo", category: "Extras", description: "Porción de camarones al ajillo.", price: 40, available: true },
            { name: "Porción diabla", category: "Extras", description: "Porción de camarones a la diabla.", price: 40, available: true },
            { name: "Porción empanizado", category: "Extras", description: "Porción de camarones empanizados.", price: 40, available: true },
            { name: "Porción encebollados", category: "Extras", description: "Porción de camarones encebollados.", price: 40, available: true },
            { name: "Porción de tortillas", category: "Extras", description: "Porción de tortillas frescas.", price: 5, available: true },
            { name: "Porción de tostadas", category: "Extras", description: "Porción de tostadas.", price: 8, available: true },
            { name: "Caldito de Camarones", category: "Platos Fuertes", description: "Caldito de camarones.", price: 35, available: true },
            { name: "Camarones Ajillo", category: "Platos Fuertes", description: "Camarones al ajillo.", price: 65, available: true },
            { name: "Camarones Diabla", category: "Platos Fuertes", description: "Camarones a la diabla.", price: 65, available: true },
            { name: "Camarones Empanizados", category: "Platos Fuertes", description: "Camarones empanizados.", price: 65, available: true },
            { name: "Camarones Encebollados", category: "Platos Fuertes", description: "Camarones encebollados.", price: 65, available: true },
            { name: "Extra", category: "Extras", description: "Cargo extra genérico.", price: 5, available: true },
            { name: "Mar y Tierra", category: "Platos Fuertes", description: "Combinación de mar y tierra.", price: 130, available: true },
            { name: "Caldo de Mariscos", category: "Platos Fuertes", description: "Caldo tradicional de mariscos.", price: 95, available: true },
            { name: "Caldo de Camarones", category: "Platos Fuertes", description: "Caldo de camarones.", price: 65, available: true },
            { name: "Pechuga Empanizada", category: "Platos Fuertes", description: "Pechuga empanizada.", price: 45, available: true },
            { name: "Pechuga a la Plancha", category: "Platos Fuertes", description: "Pechuga a la plancha.", price: 45, available: true },
            { name: "Carne a la plancha", category: "Platos Fuertes", description: "Carne a la plancha.", price: 80, available: true },
            { name: "Camarón medio", category: "Platos Fuertes", description: "Media porción de camarones.", price: 40, available: true },
            { name: "Ceviche Mixto", category: "Platos Fuertes", description: "Ceviche mixto refrescante.", price: 50, available: true },
            { name: "Ceviche de Camarón", category: "Platos Fuertes", description: "Ceviche de camarón.", price: 60, available: true },
            { name: "Mojarra Frita", category: "Platos Fuertes", description: "Mojarra frita según tamaño solicitado.", price: 110, available: true },
            { name: "Mojarra Vapor", category: "Platos Fuertes", description: "Mojarra al vapor según tamaño solicitado.", price: 110, available: true },
            { name: "Mojarra Frita con Camarones", category: "Platos Fuertes", description: "Mojarra con camarones.", price: 150, available: true },
            { name: "Costillas Barbacoa", category: "Platos Fuertes", description: "Costillas en barbacoa.", price: 65, available: true },
            { name: "Alitas Barbacoa", category: "Platos Fuertes", description: "Alitas en barbacoa.", price: 60, available: true },
            { name: "Alitas Búfalo", category: "Platos Fuertes", description: "Alitas estilo búfalo.", price: 60, available: true },
            { name: "Alitas Empanizadas", category: "Platos Fuertes", description: "Alitas empanizadas.", price: 60, available: true },
            { name: "Hamburguesa de Res", category: "Hamburguesas", description: "Hamburguesa de res.", price: 40, available: true },
            { name: "Hamburguesa de Pollo", category: "Hamburguesas", description: "Hamburguesa de pollo.", price: 40, available: true },
            { name: "Hamburguesa de Tocino", category: "Hamburguesas", description: "Hamburguesa de tocino.", price: 50, available: true },
            { name: "Hamburguesa Torito", category: "Hamburguesas", description: "Hamburguesa Torito.", price: 45, available: true },
            { name: "Hamburguesa Doble", category: "Hamburguesas", description: "Hamburguesa doble.", price: 60, available: true },
            { name: "Hamburguesa de Camarón", category: "Hamburguesas", description: "Hamburguesa de camarón.", price: 50, available: true },
            { name: "Capuccino", category: "Bebidas Calientes (Starbucks)", description: "Bebida caliente estilo Starbucks.", price: 25, available: true },
            { name: "Latte", category: "Bebidas Calientes (Starbucks)", description: "Latte.", price: 25, available: true },
            { name: "Caramel Macchiato", category: "Bebidas Calientes (Starbucks)", description: "Caramel macchiato.", price: 25, available: true },
            { name: "White Mocha", category: "Bebidas Calientes (Starbucks)", description: "White mocha.", price: 25, available: true },
            { name: "Capuccino", category: "Bebidas calientes", description: "Capuccino clásico.", price: 18, available: true },
            { name: "Café con leche", category: "Bebidas calientes", description: "Café con leche.", price: 15, available: true },
            { name: "Café con cremora", category: "Bebidas calientes", description: "Café con cremora.", price: 15, available: true },
            { name: "Té (variedad)", category: "Bebidas calientes", description: "Té de variedad.", price: 15, available: true },
            { name: "Chocolate", category: "Bebidas calientes", description: "Chocolate caliente.", price: 18, available: true },
            { name: "Café", category: "Bebidas calientes", description: "Café de la casa.", price: 15, available: true },
            { name: "Limonada", category: "Bebidas Naturales", description: "Limonada fresca.", price: 15, available: true },
            { name: "Naranjada", category: "Bebidas Naturales", description: "Naranjada.", price: 15, available: true },
            { name: "Jamaica", category: "Bebidas Naturales", description: "Jamaica.", price: 15, available: true },
            { name: "Shakalaka", category: "Bebidas - Licuados", description: "Shakalaka.", price: 10, available: true },
            { name: "LimoSoda", category: "Bebidas Naturales", description: "LimoSoda.", price: 20, available: true },
            { name: "Naranjada Con Soda", category: "Bebidas Naturales", description: "Naranjada con soda.", price: 20, available: true },
            { name: "Licuado de Fresa", category: "Bebidas - Licuados", description: "Licuado de fresa.", price: 15, available: true },
            { name: "Cimarrona", category: "Bebidas Naturales", description: "Cimarrona.", price: 25, available: true },
            { name: "Licuado de Banano", category: "Bebidas - Licuados", description: "Licuado de banano.", price: 15, available: true },
            { name: "Licuado mixto", category: "Bebidas - Licuados", description: "Licuado mixto.", price: 15, available: true },
            { name: "Coca", category: "Bebidas - Sodas", description: "Coca-Cola.", price: 10, available: true },
            { name: "Sprite", category: "Bebidas - Sodas", description: "Sprite.", price: 10, available: true },
            { name: "Fanta", category: "Bebidas - Sodas", description: "Fanta.", price: 10, available: true },
            { name: "Orange", category: "Bebidas - Sodas", description: "Orange.", price: 10, available: true },
            { name: "Tiki", category: "Bebidas - Sodas", description: "Tiki.", price: 10, available: true },
            { name: "Típico", category: "Bebidas - Sodas", description: "Típico.", price: 10, available: true },
            { name: "Tamarindo", category: "Bebidas Naturales", description: "Tamarindo.", price: 15, available: true },
            { name: "Agua pura", category: "Bebidas Naturales", description: "Agua pura embotellada.", price: 10, available: true },
            { name: "Salvavidas (Soda)", category: "Bebidas - Sodas", description: "Salvavidas (soda).", price: 10, available: true },
            { name: "Mineral (Soda)", category: "Bebidas - Sodas", description: "Mineral (soda).", price: 10, available: true },
            { name: "Yogurt con frutas", category: "Postres", description: "Yogurt con frutas.", price: 15, available: true },
            { name: "Copa de helado", category: "Postres", description: "Copa de helado.", price: 15, available: true },
            { name: "Crepas", category: "Postres", description: "Crepas.", price: 35, available: true },
            { name: "Crepa con helado", category: "Postres", description: "Crepa con helado.", price: 45, available: true },
            { name: "Plato de frutas", category: "Postres", description: "Plato de frutas.", price: 15, available: true },
        ];

        for (const item of baseItems) {
            const exists = await MenuItem.findOne({ name: item.name, category: item.category, isDeleted: { $ne: true } });
            if (!exists) {
                await MenuItem.create({ ...item, price: Number(item.price || 0) });
                continue;
            }

            const priceValue = Number(item.price || 0);
            const shouldUpdatePrice = priceValue > 0 && (!exists.price || Number(exists.price) === 0);
            const shouldUpdateDescription = !exists.description || exists.description.trim() === '';
            const updates = {};

            if (shouldUpdatePrice) updates.price = priceValue;
            if (shouldUpdateDescription) updates.description = item.description;
            if (typeof item.available === 'boolean' && exists.available !== item.available) updates.available = item.available;

            if (Object.keys(updates).length > 0) {
                await MenuItem.updateOne({ _id: exists._id }, { $set: updates });
            }
        }

        console.log("[Seed] Menú base verificado.");
    } catch (error) {
        console.error("[Seed] Error al crear el menú base:", error.message);
    }
};

const seedInternalProfiles = async () => {
    try {
        const defaultProfiles = [
            {
                username: process.env.SEED_ADMIN_USERNAME || "adminrestaurante",
                email: (process.env.SEED_ADMIN_EMAIL || "adminrestaurante@losrezagados.com").toLowerCase().trim(),
                password: process.env.SEED_ADMIN_PASSWORD || "Admin123",
                roleName: process.env.SEED_ADMIN_ROLE || "ADMIN",
                label: "admin"
            },
            {
                username: process.env.SEED_COCINA_USERNAME || "cocina",
                email: (process.env.SEED_COCINA_EMAIL || "cocina@losrezagados.com").toLowerCase().trim(),
                password: process.env.SEED_COCINA_PASSWORD || "Cocina123",
                roleName: process.env.SEED_COCINA_ROLE || "COCINA",
                label: "cocina"
            },
            {
                username: process.env.SEED_RECEPCION_USERNAME || "recepcion",
                email: (process.env.SEED_RECEPCION_EMAIL || "recepcion@losrezagados.com").toLowerCase().trim(),
                password: process.env.SEED_RECEPCION_PASSWORD || "Recepcion123",
                roleName: process.env.SEED_RECEPCION_ROLE || "RECEPCION",
                label: "recepcion"
            }
        ];

        for (const profile of defaultProfiles) {
            const role = await Role.findOneAndUpdate(
                { name: profile.roleName },
                { name: profile.roleName },
                { new: true, upsert: true }
            );

            let user = await User.findOne({ email: profile.email });
            if (!user) {
                user = new User({
                    username: profile.username,
                    email: profile.email,
                    password: profile.password,
                    role: role._id,
                    verified: true,
                    verificationToken: null,
                    verificationTokenExpires: null,
                    loginAttempts: 0,
                    lockUntil: null
                });
                await user.save();
                console.log(`[Seed] Perfil ${profile.label} creado: ${profile.email}`);
                continue;
            }

            if (user.role?.toString() !== role._id.toString()) {
                user.role = role._id;
            }

            if (!user.verified) {
                user.verified = true;
                user.verificationToken = null;
                user.verificationTokenExpires = null;
            }

            const passwordMatches = await user.comparePassword(profile.password);
            if (!passwordMatches) {
                user.password = profile.password;
            }

            await user.save();
            console.log(`[Seed] Perfil ${profile.label} actualizado: ${profile.email}`);
        }
    } catch (error) {
        console.error("Error al sembrar perfiles internos:", error);
    }
};

const options = {
    definition: {
        openapi: "3.0.0",
        info: {
            title: "API Restaurante",
            version: "1.0.0",
            description: "API completa para gestión de restaurante"
        },
        servers: [
            { url: "http://localhost:3000", description: "Node.js API" },
            { url: "http://localhost:5022", description: ".NET API" }
        ],
        security: [
            {
                bearerAuth: []
            }
        ],

        components: {
            securitySchemes: {
                bearerAuth: {
                    type: "http",
                    scheme: "bearer",
                    bearerFormat: "JWT"
                }
            },

            schemas: {
                    Restaurant: {
                    type: "object",
                    properties: {
                        _id: { type: "string" },
                        name: { type: "string" },
                        address: { type: "string" },
                        phone: { type: "string" },
                        city: { type: "string" }
                    }
                },
                MenuItem: {
                    type: "object",
                    properties: {
                        _id: { type: "string" },
                        name: { type: "string" },
                        price: { type: "number" },
                        restaurant: { type: "string" }
                    }
                },
                Order: {
                    type: "object",
                    properties: {
                        _id: { type: "string" },
                        table: { type: "string" },
                        items: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    menuItem: { type: "string" },
                                    quantity: { type: "number" },
                                    price: { type: "number" }
                                }
                            }
                        },
                        total: { type: "number" },
                        status: { type: "string" }
                    }
                },
                Table: {
                    type: "object",
                    properties: {
                        _id: { type: "string" },
                        number: { type: "number" },
                        capacity: { type: "number" },
                        restaurant: { type: "string" },
                        status: { 
                            type: "string", 
                            enum: ["disponible", "no disponible"] 
                        }
                    }
                },
                Reservation: {
                    type: "object",
                    properties: {
                        _id: { type: "string" },
                        customerName: { type: "string" },
                        customerPhone: { type: "string" },
                        customerEmail: { type: "string" },
                        reservationDate: { type: "string", format: "date-time" },
                        numberOfGuests: { type: "number" },
                        restaurant: { type: "string" },
                        table: { type: "string" },
                        isDeleted: { type: "boolean" }
                    }
                },
                    Review: {
                    type: "object",
                    properties: {
                        _id: { type: "string" },
                        restaurant: { type: "string" },
                        rating: { type: "number" },
                        comment: { type: "string" }
                    }
                },
                AuthResponse: {
                    type: "object",
                    properties: {
                        success: { type: "boolean" },
                        message: { type: "string" },
                        token: { type: "string", nullable: true }
                    }
                }
            }
        }
    },

    apis: ["./server.js", "./src/routes/restaurant.routes.js", "./src/routes/menuItem.routes.js", "./src/routes/order.routes.js"]
};

const specs = swaggerJsdoc(options);
app.get("/health", (req, res) => res.status(200).json({ status: "ok" }));
app.get("/debug-mongo", async (req, res) => {
  try {
    await mongoose.connection.asPromise();
    res.json({ ok: true, readyState: mongoose.connection.readyState });
  } catch (e) {
    res.status(500).json({
      ok: false,
      name: e.name,
      message: e.message,
      reason: e.reason ? String(e.reason) : null
    });
  }
});
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(specs));


app.use("/restaurants", restaurantRoutes);
app.use("/menu-items", menuItemRoutes);
app.use("/menu", menuItemRoutes);
app.use("/orders", orderRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/roles", roleRoutes);
app.use("/tables", tableRoutes);
app.use("/api/reservations", reservationRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error("Error:", err.message);
    console.error(err.stack);
    res.status(500).json({ message: "Error interno del servidor", error: err.message });
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    console.error('Excepción no capturada:', error);
    process.exit(1);
});

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
    console.error('Rechazo no manejado en:', promise, 'razón:', reason);
});

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
    console.log("Servidor en http://localhost:" + PORT);
    console.log("Swagger UI disponible en: http://localhost:" + PORT + "/api-docs");
});

server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
        console.error(`El puerto ${PORT} ya está en uso. Cierra el proceso existente o cambia PORT en .env.`);
        process.exit(1);
    }
    console.error('Error de servidor:', error);
    process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM recibido, cerrando servidor...');
    server.close(() => {
        console.log('Servidor cerrado');
        process.exit(0);
    });
});